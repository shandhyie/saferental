# uButia
uButia is a free bootstrap template created by freshdesignweb teams. The template includes the complete source files for download such as HTML5, CSS, CSS3 and JavaScript for easy customization. 
# Theme Demo
<img src="https://github.com/grahambill/ubutia/blob/master/ubutia.jpg?raw=true">
<a href="https://www.freshdesignweb.com/demo/ubutia/">View Demo</a> <a href="https://github.com/grahambill/ubutia/archive/master.zip">Download</a>

There are so many awesome bootstrap templates that have created amazing free resources using Bootstrap. Those free download resources wanted to help spread the word and share their work with our readers. So, we compiled a list of free frontend templates that we thought are beautiful and worth sharing. 

# Scripts included:
<ul>
<li>Bootstrap Framework</li>
<li>Font Awesome</li>
<li>jQuery Magnific Popup</li>
<li>Carousel jQuery</li>
<li>Validator - HTML5 </li>
</ul>
# Other templates and useful resources
<ul>
<li> <a href="https://www.freshdesignweb.com/free-bootstrap-admin-templates/">Free Bootstrap Admin Templates</a>  List of the best Free Bootstrap admin templates that are available for download for personal and commercial use.</li>
<li><a href="https://www.freshdesignweb.com/free-html5-css3-templates/">Free HTML5 Website Templates</a></li>  Long list of the best free HTML5 Website templates.And it is available for personal and commercial use.
<li><a href="https://www.freshdesignweb.com/free-responsive-wordpress-themes/">Free Responsive WordPress Themes</a></li>  Long list of the best free WordPress themes that are all licensed under GPL and are available for personal and commercial use without restrictions.
<li><a href="https://www.freshdesignweb.com/free-blogger-templates/">Free Blogger Templates</a></li>  Long list of the best free Blogger templates that are all licensed under GPL and are available for personal and commercial use.
</ul>

# License information
uButia is licensed under The MIT License (MIT). Which means that you can use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software. But you always need to state that freshDesignweb is the original author of this template.

Project is developed and maintained by <a href="https://www.freshdesignweb.com/">freshDesignweb</a>
